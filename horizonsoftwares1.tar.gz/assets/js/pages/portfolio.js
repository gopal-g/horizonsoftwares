var Portfolio = function () {


    return {

        init: function () {
            $('.sorting-grid').mixitup();
        }

    };

}();