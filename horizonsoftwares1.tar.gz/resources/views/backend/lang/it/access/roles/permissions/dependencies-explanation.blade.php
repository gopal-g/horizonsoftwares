Questa sezione permette di specificare che un permesso dipende dal fatto che un utente abbia uno o più altri permessi.<br/><br/>
Per esempio: questo permesso potrebbe essere <strong>create-user</strong>, ma se l'utente non ha anche i permessi
<strong>view-backend</strong> e <strong>view-access-management</strong> non riuscirà a visualizzare la pagina
<strong>Crea Utente</strong>.
