<section id="details" class="page">

    <section class="section">

        <div class="container">

            <div class="row">

                <hgroup class="slogan align-center opacity">
                    <h1>We are more than <span>happy</span> to offer you...</h1>
                </hgroup>

            </div><!--/ .row-->

            <div class="row">

                <div class="col-xs-12">

                    <div class="flexslider opacity">

                        <ul class="slides">
                            <li data-icon="icon-paper-plane-2" data-title="ideas">
                                <p>
                                </p>
                            </li>
                            <li data-icon="icon-pencil-7" data-title="design">
                                <p>
                                </p>                    
                            </li>
                            <li data-icon="icon-code" data-title="Development">
                                <p>
                                </p>        
                            </li>
                            <li data-icon="icon-chart-bar" data-title="Optimization">
                                <p>
                                </p>                            
                            </li>

                            <li data-icon="icon-comment-6" data-title="support">
                                <p>
                                </p>                            
                            </li>
                        </ul>

                    </div><!--/ .flexslider-->  

                </div>

            </div><!--/ .row-->

        </div><!--/ .container-->

    </section><!--/ .section-->

</section><!--/ .page-->
