<?php $__env->startSection('title'); ?>
  @parent
  	| Blog
<?php $__env->stopSection(); ?>

<?php $__env->startSection('sub-content'); ?>

    <?php echo $__env->make('includes.tags', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	    
    <!-- latest -->
    <div class="col-md-5">

		<h2 class="title text-right">LATEST</h1>

	    <div class="grid">

	        <!-- @ if ($blogs->count()) -->
	        <?php if(isset($blogs) && count($blogs)): ?>

	        <?php foreach($blogs as $blog): ?>
	        <li id="<?php echo e($blog->id); ?>">
                <div>
	                <div class="image col-sm-4">
	                    <a href="<?php echo e(route('blog.show', $blog->slug)); ?>" class="lazy">
	                        <!-- data-original="<?php echo e($blog->image); ?>"  -->
	                        <!-- <img src="<?php echo e($blog->image); ?>"  -->
	                        <!-- <img src="/assets/img/nyayo.jpg"  -->
	                        <img src="/assets/img/nai.jpg" 
	                        alt="" class="lazy" height="100%" width="300" >
	                    </a>
	                </div>
	                <div class="title col-sm-8">
	                    <a href="<?php echo e(route('blog.show', $blog->slug)); ?>" class="read_more"><?php echo e($blog->title); ?></a>
		                <br>
		                <?php $d = Date::parse($blog->created_at); ?>
		                <div class="author">
		                    By <a href="<?php echo e(route('users.show', $blog->user->username)); ?>"><?php echo e($blog->user->name()); ?></a> 
		                    <span class="updated_at"><?php echo e($d->format('d M Y')); ?></span>
		                </div>

		                <div class="tagz">
		                  <?php foreach($blog->tags as $tagg): ?>
		                  <a href="<?php echo e(route('tags.show', $tagg->slug)); ?>"><span class="badge"><?php echo e($tagg->name); ?></span></a>
		                  <?php endforeach; ?>
		                  <span class="stars"><i class="icon icon-star"></i><?php echo e($blog->starsCount()); ?></span>
		                </div>
	                </div>
	            </div>
	        </li>
	        <?php endforeach; ?>


	        <?php else: ?>
	          There are no posts.
	        <?php endif; ?>

	    </div>
    
    </div>
	<!-- /LATEST -->

    <!-- trending -->
    <div class="col-md-5">

		<h2 class="title text-right">TRENDING</h1>
 		
 		<div class="grid">

	        <?php if(isset($blogs) && count($blogs)): ?>
	        
	        <?php
			    $trending = Article::select(DB::raw('blogs.*, count(*) as `aggregate`'))
				    ->join('stars', 'blogs.id', '=', 'stars.blog_id')
				    ->groupBy('blog_id')
				    ->orderBy('aggregate', 'desc')->paginate(10);
		    ?>

	        <?php foreach($trending as $blog): ?>
	        <li class="block-<?php echo e(rand(1,3)); ?>" id="<?php echo e($blog->id); ?>">
                <div>
	                <div class="image col-sm-4">
	                    <a href="<?php echo e(route('blog.show', $blog->slug)); ?>" class="lazy">
	                        <!-- data-original="<?php echo e($blog->image); ?>"  -->
	                        <!-- <img src="<?php echo e($blog->image); ?>"  -->
	                        <!-- <img src="/assets/img/nyayo.jpg"  -->
	                        <img src="/assets/img/nai.jpg" 
	                        alt="" class="lazy" height="100%" width="300" >
	                    </a>
	                </div>
	                <div class="title col-sm-8">
	                    <a href="<?php echo e(route('blog.show', $blog->slug)); ?>" class="read_more"><?php echo e($blog->title); ?></a>
		                <br>
		                <?php $d = Date::parse($blog->created_at); ?>
		                <div class="author">
		                    By <a href="<?php echo e(route('users.show', $blog->user->username)); ?>"><?php echo e($blog->user->name()); ?></a> 
		                    <span class="updated_at"><?php echo e($d->format('d M Y')); ?></span>
		                </div>

		                <div class="tagz">
		                  <?php foreach($blog->tags as $tagg): ?>
		                  <a href="<?php echo e(route('tags.show', $tagg->slug)); ?>"><span class="badge"><?php echo e($tagg->name); ?></span></a>
		                  <?php endforeach; ?>
		                  <span class="stars"><i class="icon icon-star"></i><?php echo e($blog->starsCount()); ?></span>
		                </div>
	                </div>
	            </div>
	        </li>
	        <?php endforeach; ?>


	        <?php else: ?>
	          There are no posts.
	        <?php endif; ?>

	    </div>
	</div>
    <!-- /trending -->

    <?php if(isset($blogs) && count($blogs)): ?>
    <div id="pagination">
      <?php echo e($blogs->links()); ?>

    </div>
    <?php endif; ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
@parent
	<?php echo e(Html::style('assets/css/grid-animations.css')); ?>


	<style type="text/css">
		.blog {
			padding-top: 150px;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
@parent
<?php $__env->stopSection(); ?>
<?php echo $__env->make('blog.blog', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>