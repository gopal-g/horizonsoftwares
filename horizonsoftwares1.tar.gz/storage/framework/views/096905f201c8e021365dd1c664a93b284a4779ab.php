<?php echo e(trans('strings.emails.reset_password')); ?>: <?php echo e(url('password/reset/'.$token)); ?>

