  <!-- - - - - - - - - - - - - - Header - - - - - - - - - - - - - - - - --> 
  

  <header id="header" class="transparent">

    <div class="header-in clearfix">

      <div id="top-left" class="col-md-6 col-sm-12 col-xs-12">
          <h1 id="logo"><a href="<?php echo e(Request::path() == 'blog' ? route('home') : ''); ?>">Horizon Softwares</a></h1> 
          <br/>
          <h4 id="creed">we develop softwares</h4>
          <form action="<?php echo e(route('blog.search')); ?>" method="post" accept-charset="utf-8" class="search">
            <button type="submit" class="icon icon-search-1"></button>
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" >
            <input type="text" name="query" value="<?php echo e(isset($query) ? $query : 'Search Blog...'); ?>" placeholder="Search Blog..." 
                onclick="this.placeholder='Type...';this.value=='Search Blog...'?this.value='':true" 
                onblur="this.value=this.value==''?'Search Blog...':this.value;this.placeholder='Search Blog...'" required>

            <?php if(Auth::check()): ?>
                <a href="<?php echo e(route('blog.create')); ?>" class="icon icon-pencil"></a>
            <?php else: ?>
                <a>Log In</a> &#8226; 
                <a href="#signin" data-toggle="modal" class="icon icon-pencil"></a>
            <?php endif; ?>
          </form><!--/ .search-form--> 
      </div>


      <a id="responsive-nav-button" class="responsive-nav-button" href="#"></a>

      <nav id="navigation" class="navigation">

        <ul>
          <?php $home = Request::segment(1) ? route('home') : ''; ?>
          <li><a href="<?php echo e('/blog'); ?>" id="blog">Blog</a></li>
          <li><a href="<?php echo e($home); ?>#about">About</a></li>
          <li><a href="<?php echo e($home); ?>#folio">Folio</a></li>
          <!-- <li><a href="<?php echo e($home); ?>#partners">Partners</a></li> -->
          <!-- <li><a href="<?php echo e($home); ?>#testimonials">Testimonials</a></li> -->
          <li><a href="<?php echo e($home); ?>#team">Team</a></li>
          <li><a href="#footer">Contacts</a></li>
        </ul>

      </nav><!--/ #navigation-->

      <img src="/assets/img/sil.png" alt="" class="nai hide">

    </div><!--/ .header-in-->

  </header><!--/ #header-->


  <!-- - - - - - - - - - - - - end Header - - - - - - - - - - - - - - - -->