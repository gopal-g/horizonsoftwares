<?php if(Session::get('toastr')): ?>
    <script>
        $(document).ready(function() {
        	toastr.options.timeOut = 2000;
        	toastr.options.extendedTimeOut = 2000;
            toastr.<?php echo e(Session::remove('toastr.level')); ?>

            ("<?php echo e(Session::remove('toastr.message')); ?>");
        });
    </script>
<?php endif; ?>