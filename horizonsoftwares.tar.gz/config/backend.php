<?php

return [

    /**
     * Skin for Admin LTE backend theme
     *
     * Available options:
     *
     * black
     * black-light
     * blue
     * blue-light
     * green
     * green-light
     * purple
     * purple-light
     * red
     * red-light
     * yellow
     * yellow-light
     */
    'theme' => 'blue',
];