
<section id="intro" class="page">

    <section class="section padding-off">

        <div id="layerslider-container">

            <div id="layerslider">

                <div class="ls-layer" style="text-align:center; slidedirection: left; durationin: 1500; durationout: 1500; easingin: easeInOutQuint; timeshift: -500;">

                    <img alt="" class="ls-bg" src="assets/img/bg/nairobi.jpg">

                    <h1 class="ls-s2" style="left:auto; top: 43%; width:100%; slidedirection : top; slideoutdirection : fade; scaleout : 0.75; durationin : 2000; durationout : 1000; easingin : easeInOutQuint; easingout : easeInOutQuint;">
                        <!-- We Do Awesome -->
                        We Create
                    </h1>

                    <h1 class="ls-s2" style="left:auto; top: 57%; width:100%; slidedirection : bottom; slideoutdirection : fade; scaleout : 0.75; durationin : 2000; durationout : 1000; easingin : easeInOutQuint; easingout : easeInOutQuint;">
                        <!-- Web Apps -->
                        Great Products
                    </h1>

                </div><!--/ .ls-layer-->

                <div class="ls-layer" style="text-align:center; slidedirection: right; durationin: 1500; durationout: 1500; easingin: easeInOutQuint; timeshift: -500;">

                    <img alt="" class="ls-bg" src="assets/img/bg/central-park.jpg">

                    <h1 class="ls-s2" style="left:auto; top: 43%; width:100%; slidedirection : top; slideoutdirection : fade; scaleout : 0.75; durationin : 2000; durationout : 1000; easingin : easeInOutQuint; easingout : easeInOutQuint;">
                        We really love
                    </h1>

                    <h1 class="ls-s2" style="left:auto; top: 57%; width:100%; slidedirection : bottom; slideoutdirection : fade; scaleout : 0.75; durationin : 2000; durationout : 1000; easingin : easeInOutQuint; easingout : easeInOutQuint;">
                        what we do
                    </h1>

                </div><!--/ .ls-layer-->

                <div class="ls-layer" style="text-align:center; slidedirection: right; durationin: 1500; durationout: 1500; easingin: easeInOutQuint; timeshift: -500;">

                    <!-- <img alt="" class="ls-bg" src="assets/img/bg/times-tower.jpg"> -->
                    <img alt="" class="ls-bg" src="assets/img/bg/university-way.jpg">

                    <h1 class="ls-s2" style="left:auto; top: 43%; width:100%; slidedirection : top; slideoutdirection : fade; scaleout : 0.75; durationin : 2000; durationout : 1000; easingin : easeInOutQuint; easingout : easeInOutQuint;">
                        and we do
                    </h1>

                    <h1 class="ls-s2" style="left:auto; top: 57%; width:100%; slidedirection : bottom; slideoutdirection : fade; scaleout : 0.75; durationin : 2000; durationout : 1000; easingin : easeInOutQuint; easingout : easeInOutQuint;">
                        what we love!
                    </h1>

                </div><!--/ .ls-layer-->



                <!--/ .ls-layer 78, 104, 108, 113, 202, 226-->

            </div><!--/ #layerslider-->

        </div><!--/ #layerslider-container-->   

        <ul class="keydown">
            <li class="up"></li>
            <li class="left"></li>
            <li class="down"></li>
            <li class="right"></li>
        </ul><!--/ .keydown-->  

    </section><!--/ .section-->

</section><!--/ .page-->
