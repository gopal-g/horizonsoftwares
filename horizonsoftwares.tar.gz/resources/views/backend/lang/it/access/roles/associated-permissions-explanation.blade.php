Un permesso che ha a fianco del nome una <small><strong>(D)</strong></small> indica che ci sono delle dipendenze che verranno controllate automaticamente quando selezionerai quel permesso.
Potrai gestire ogni singola dipendenza nella scheda <strong>Dipedenze</strong> della pagina <strong>Modifica permessi</strong>.
