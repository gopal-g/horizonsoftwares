Este apartado sirve para especificar que este Permiso depende de un Usuario que dispone de uno o mas otros Permisos.<br/><br/>
    Por ejemplo: Este permiso puede ser <strong>create-user</strong>, pero si el Usuarios no disponen de Permisos <strong>view-backend</strong> y <strong>view-access-management</strong>, no podran acceder a la pagina de <strong>Nuevo Usuario</strong>.
